/* global QUnit */

sap.ui.require(["locadora/sap/projetolocadorafiori/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
