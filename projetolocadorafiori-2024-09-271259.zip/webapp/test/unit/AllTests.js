sap.ui.define([
	"locadorasap/projetolocadorafiori/test/unit/controller/LocadoraView.controller"
], function () {
	"use strict";
});
