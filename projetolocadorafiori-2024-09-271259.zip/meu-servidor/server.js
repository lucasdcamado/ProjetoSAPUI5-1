const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 3000;
const SECRET_KEY = 'seuSegredoParaJWT'; // Chave secreta para assinar o JWT

app.use(bodyParser.json());

// Endpoint para autenticação de login
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;

    // Lógica de validação de credenciais (simulado)
    if (username === 'admin' && password === 'senha123') {
        // Se as credenciais forem válidas, gerar um token JWT
        const token = jwt.sign({ username: username }, SECRET_KEY, { expiresIn: '1h' });

        // Retornar o token JWT como resposta
        res.json({ token: token });
    } else {
        // Se as credenciais forem inválidas, retornar erro 401
        res.status(401).json({ message: 'Credenciais inválidas' });
    }
});

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});